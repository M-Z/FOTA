/*
 * GSM_conf.h
 *
 *  Created on: 25 Sep 2019
 *      Author: Mario
 */

#ifndef GSM_CONF_H_
#define GSM_CONF_H_


#define FTPPORT		21


#endif /* GSM_CONF_H_ */
