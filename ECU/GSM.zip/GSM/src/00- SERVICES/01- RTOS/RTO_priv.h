#ifndef _RTO_PRIV_H
#define _RTO_PRIV_H

#define QUEUE_LENGTH 		100			// Scheduler tasks limit
#define MAX_LENGTH_TYPE 	u8			// Data-type limit to hold max queue length

static void RTO_voidSchedular(void);
static void setFlag(void);

#endif
