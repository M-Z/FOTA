#ifndef _FPEC_INT_H
#define _FPEC_INT_H

void FPEC_voidProgram(u32, u32);
void FPEC_voidPageErase(u32);
void FPEC_voidMassErase(void);

#endif
